# Pokemon

Card plugin made from json using tool by Cyantist

## Cards as of now

- Blastoise
- Bulbasaur
- Charizard
- Charmander
- Charmeleon
- Ivysaur
- Raticate
- Rattata
- Squirtle
- Venasaur
- Wartortle
